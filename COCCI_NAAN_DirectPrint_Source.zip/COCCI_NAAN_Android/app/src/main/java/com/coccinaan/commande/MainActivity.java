package com.coccinaan.commande;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.webkit.WebViewClient;
import android.os.Handler;
import android.os.Looper;
import com.starmicronics.stario.StarIOPort;
import com.starmicronics.stario.StarPrinterStatus;
import com.starmicronics.starioextension.ICommandBuilder;
import com.starmicronics.starioextension.StarIoExt;
import com.starmicronics.starioextension.StarIoExt.Emulation;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DirectPrinterBridge(), "AndroidPrinter");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }
        });
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }


    /**
     * Prints the existing HTML ticket through Star's SDK without launching PassPRNT.
     * The ticket is rendered to a 576-dot bitmap, then sent to the paired TSP100IIIBI.
     */
    private class DirectPrinterBridge {
        @JavascriptInterface
        public void printHtml(String html) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ticket vide.", Toast.LENGTH_LONG).show());
                return;
            }
            runOnUiThread(() -> renderTicketAndPrint(html));
        }
    }

    private void renderTicketAndPrint(String html) {
        final WebView ticketView = new WebView(MainActivity.this);
        ticketView.setBackgroundColor(Color.WHITE);
        ticketView.getSettings().setJavaScriptEnabled(false);
        ticketView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.postDelayed(() -> {
                    try {
                        int width = 576;
                        int contentHeight = Math.max(1, (int) Math.ceil(view.getContentHeight()
                                * view.getScale()));
                        // Avoid allocating an unreasonable bitmap if malformed HTML is passed.
                        contentHeight = Math.min(contentHeight, 12000);
                        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                                View.MeasureSpec.makeMeasureSpec(contentHeight, View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, width, contentHeight);
                        Bitmap bitmap = Bitmap.createBitmap(width, contentHeight, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(bitmap);
                        canvas.drawColor(Color.WHITE);
                        view.draw(canvas);
                        ticketView.destroy();
                        sendBitmapToStarPrinter(bitmap);
                    } catch (Exception e) {
                        ticketView.destroy();
                        Toast.makeText(MainActivity.this, "Erreur préparation ticket: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                }, 250);
            }
        });
        ticketView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    private void sendBitmapToStarPrinter(Bitmap bitmap) {
        new Thread(() -> {
            StarIOPort port = null;
            try {
                // TSP100IIIBI uses StarGraphic emulation and Bluetooth port BT:.
                ICommandBuilder builder = StarIoExt.createCommandBuilder(Emulation.StarGraphic);
                builder.beginDocument();
                builder.appendBitmap(bitmap, true, 576, true);
                builder.appendCutPaper(StarIoExt.CutPaperAction.PartialCutWithFeed);
                builder.endDocument();
                byte[] commands = builder.getCommands();

                port = StarIOPort.getPort("BT:", "", 10000, MainActivity.this);
                StarPrinterStatus status = port.beginCheckedBlock();
                if (status.offline) {
                    throw new Exception("L'imprimante est hors ligne. Vérifiez le papier et le Bluetooth.");
                }
                port.writePort(commands, 0, commands.length);
                status = port.endCheckedBlock();
                if (status.coverOpen) throw new Exception("Fermez le capot de l'imprimante.");
                if (status.receiptPaperEmpty) throw new Exception("Il n'y a plus de papier.");
                if (status.offline) throw new Exception("L'imprimante est hors ligne.");
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ticket envoyé à l'imprimante.", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                final String message = e.getMessage() == null ? "Vérifiez le jumelage Bluetooth et l'imprimante." : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Impression impossible: " + message, Toast.LENGTH_LONG).show());
            } finally {
                if (port != null) {
                    try { StarIOPort.releasePort(port); } catch (Exception ignored) {}
                }
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }).start();
    }

    private boolean routeUrl(String url) {
        if (url.startsWith("cocci-naan://back")) {
            if (webView != null) webView.post(() -> webView.loadUrl("file:///android_asset/index.html"));
            return true;
        }
        if (url.startsWith("starpassprnt://")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Installez Star PassPRNT et configurez l'imprimante Bluetooth.", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return true;
        }
        return false;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getData() != null && "cocci-naan".equals(intent.getData().getScheme())) {
            if (webView != null) webView.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        Toast.makeText(this, "استعمل أزرار التطبيق للرجوع أو إنهاء الطلبية", Toast.LENGTH_SHORT).show();
    }
}
